package com.passenger.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.passenger.model.Passenger;

public interface PassengerRepository extends MongoRepository<Passenger, Integer>{

}
