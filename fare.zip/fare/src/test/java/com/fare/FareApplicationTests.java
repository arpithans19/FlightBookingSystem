package com.fare;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FareApplicationTests {

	@Test
	void contextLoads() {
	}

}
